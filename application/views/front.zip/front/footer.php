<footer class="navbar navbar-inverse text-center" style="background-color:black;color:white;">
  <p>The Company Copyright</p>  
  <form class="form-inline">Get deals:
    <input type="email" class="form-control" size="30" placeholder="Email Address" >
    <button type="button" class="btn btn-danger">Sign Up</button>
  </form>
    <p>Developed By <a href="https://www.xyz.com">www.farjana.com</a></p> 

</footer>  